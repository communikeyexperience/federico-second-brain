# ZirconIA Starter Kit — istruzioni

Versione aggiornata al 2026-07-10. Contiene: struttura PARA vuota, `Processi e Convenzioni.md` genericizzato, 5 skill comportamentali di base (Claude Code), i loro SOP sorgente, il layer di competenza coaching (`02 Aree/Coaching - Conoscenza/`, incluso il Glossario — incluso di default per scelta di prodotto, non rimuovere), lo script di audit qualità, e i Templates di base.

## Prima di iniziare — sostituzioni da fare

Cerca e sostituisci in tutti i file (in particolare `CLAUDE.md`, `Home.md`, e le SOP in `02 Aree/SOP e Procedure/`):
- `[NOME CLIENTE]` → nome della persona/cliente
- `[NOME VAULT]` → nome che vuoi dare a questo second brain

## Come ospitare il vault

Tre opzioni, nessuna eseguita automaticamente da questo kit (nessun accesso diretto a servizi cloud):

1. **Cartella locale + sync file (iCloud Drive / Google Drive / Dropbox)**: il modo più semplice — sposta questa cartella dentro la cartella sincronizzata del servizio scelto, apri il vault in Obsidian da lì.
2. **Obsidian Sync** (a pagamento): cronologia versioni + sync multi-device incluso, senza disciplina di commit — scelta fatta per il vault originale (uso singolo/famiglia). Attivabile dalle impostazioni di Obsidian una volta aperto il vault.
3. **Git**: da valutare se il vault-cliente avrà più collaboratori tecnici che devono lavorarci in parallelo — non necessario per un vault a uso singolo.

## Come aprire il vault

1. Apri Obsidian → "Apri cartella come vault" → seleziona questa cartella.
2. Se vuoi che Claude Code operi su questo vault con le skill comportamentali attive, apri una sessione Claude Code con working directory su questa stessa cartella — la scoperta di `.claude/skills/` è automatica.
3. Se invece lavori tramite Cowork (Claude desktop), collega questa cartella come cartella di lavoro — le skill in `.claude/skills/` non vengono auto-scoperte da Cowork allo stesso modo di Claude Code: il contenuto di `CLAUDE.md` va comunque rispettato come istruzioni di progetto, ma il comportamento delle skill va replicato leggendo direttamente le SOP corrispondenti in `02 Aree/SOP e Procedure/` quando il trigger si presenta.

## Cosa NON è incluso (di proposito)

- Nessun contenuto personale del vault originale (famiglia, clienti, progetti, decisioni finanziarie).
- La skill di voce personale/ghostwriting (troppo specifica di una persona per essere riusata).
- Qualunque dato sensibile.

## Primi passi consigliati una volta aperto

Vedi la sezione "Primi passi per popolare questo vault" in `CLAUDE.md`.
