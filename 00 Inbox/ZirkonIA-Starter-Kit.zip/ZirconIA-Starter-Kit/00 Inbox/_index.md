---
tipo: indice
---

# Indice — 00 Inbox

*(elenco alfabetico delle note di questa cartella — aggiorna man mano che ne crei, o rilancia l'audit script che segnala le note orfane da agganciare)*

## Sottocartelle
