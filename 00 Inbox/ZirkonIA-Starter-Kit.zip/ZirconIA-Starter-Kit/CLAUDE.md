# [NOME VAULT] — istruzioni per Claude Code

Questo è il second brain di **[NOME CLIENTE]**, costruito con il metodo ZirconIA (Obsidian vault + PARA). Second brain "as a service" — questo file va mantenuto aggiornato man mano che il vault cresce.

## All'inizio di ogni sessione

Prima di rispondere a qualunque richiesta operativa, leggi **[[Processi e Convenzioni]]** (`03 Risorse/Sistema/Processi e Convenzioni.md`) — metodo PARA, stati/priorità, schema frontmatter, regole ferme specifiche di questo cliente (da popolare mano a mano).

## Skill comportamentali (`.claude/skills/`)

5 modalità operative di base, implementate come Claude Code Skill in `.claude/skills/` — Claude Code le scopre in automatico all'apertura di questa cartella e le attiva per intento (non solo parola esatta):

| Skill | Trigger | Quando si applica |
|---|---|---|
| `zirconia-core-tone` | *(default)* | Ogni volta che [NOME CLIENTE] chiede un punto di vista/analisi strategica, non solo esecuzione o ricerca |
| `educazione` | `EDUCAZIONE`, "modalità educazione", "lancia l'educational" | [NOME CLIENTE] vuole essere interrogato per consolidare/validare conoscenza nel vault |
| `mediazione` | `MEDIAZIONE` | Conflitti tra soci, disallineamenti di governance, decisioni multi-parte |
| `strategia-visione` | `STRATEGIA`, `VISIONE`, "dove potremmo arrivare" | Esplorazione di scenari di crescita/frontiere, non un conflitto da risolvere |
| `recap-stato` | `RECAP`, `STATO`, "come siamo messi" | Quadro rapido e azionabile dei progetti aperti — solo azioni/stato, niente prosa |

Se un trigger è ambiguo (potrebbe essere il nome di un progetto/cliente invece del protocollo), conferma in una riga prima di procedere invece di assumere in silenzio.

**Nota su questo starter kit**: la sesta skill del vault originale (voce personale/ghostwriting) non è inclusa qui perché troppo specifica della persona da cui deriva questo kit. Se [NOME CLIENTE] vuole una skill equivalente per la propria voce di scrittura, va costruita da zero osservando i suoi testi reali — non copiata.

**Layer di base incluso — competenza di coaching**: questo starter kit include per scelta di prodotto `02 Aree/Coaching - Conoscenza/` (con il Glossario) come conoscenza di base permanente, non opzionale. La maieutica — l'esplorazione tramite domande tipica del metodo coach — è un tratto distintivo del prodotto ZirconIA: il modo in cui le skill sopra fanno domande a [NOME CLIENTE] è calibrato su questo layer. Non rimuoverlo per "alleggerire" il vault.

**Manutenzione — nessuna sincronizzazione automatica**: le note in `02 Aree/SOP e Procedure/` restano la fonte "umana" originale (versionabile, leggibile, modificabile in Obsidian), le Skill in `.claude/skills/` sono la loro controparte eseguibile. Se modifichi una SOP, aggiorna a mano anche la Skill corrispondente (e viceversa).

## Dove sta cosa

Parti da **Home** come dashboard (da creare/popolare). Struttura PARA: `00 Inbox` (cattura), `01 Progetti` (obiettivo + fine), `02 Aree` (responsabilità continue), `03 Risorse` (clienti, capitale intellettuale, sistema), `04 Archivio`. Dettagli completi in [[Processi e Convenzioni]] — non duplicarli qui.

## Comportamento di default

- Archivia proattivamente nel vault le decisioni prese, le SOP generate, le sintesi di riunioni durante conversazioni normali, senza chiedere permesso ogni volta — chiudi il messaggio con un log sintetico delle azioni fatte sui file.
- Resta invece a chiedere conferma per decisioni realmente ambigue (scelte strutturali di cartelle/tassonomia) o quando manca un dato necessario.
- Su materie fiscali/legali/societarie: opinione strategica sì, ma dichiarata come tale — mai sostituire un professionista abilitato (commercialista, notaio, legale).

## Primi passi per popolare questo vault

Questo kit arriva "vergine" di contenuto cliente, non di metodo. I primi passi tipici:
1. Crea una nota di profilo (`[[Nome Cliente]]`) come bussola — chi è, cosa fa, per chi (sul modello della nota "Chi sono" del vault originale).
2. Usa `EDUCAZIONE` (Analisi Aperta o Intervista) per una prima sessione di profilazione profonda — valori, visione, area di attività.
3. Popola `03 Risorse/Persone.md` (indice omonimi) e le note Area man mano che emergono collaboratori, clienti, soci.
4. Esegui `python3 "03 Risorse/Sistema/audit_vault.py"` periodicamente per tenere il vault pulito (zero link rotti, zero orfani).
