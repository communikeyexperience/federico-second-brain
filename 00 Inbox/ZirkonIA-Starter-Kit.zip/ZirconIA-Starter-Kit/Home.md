---
tipo: dashboard
---

# Home

> Dashboard operativa del second brain di [NOME CLIENTE]. Punto di partenza per orientarsi nel vault.

## 🧭 Aree

*(popola con i link alle Aree principali man mano che nascono, es. attività professionale, progetti in corso)*

## 📌 Progetti attivi

*(popola con [[01 Progetti]] rilevanti)*

## 🔗 Indici di cartella (anti-orfani)

- [[00 Inbox/_index|00 Inbox]]
- [[01 Progetti/_index|01 Progetti]]
- [[02 Aree/_index|02 Aree]]
- [[03 Risorse/_index|03 Risorse]]
- [[04 Archivio/_index|04 Archivio]]

## Note

Vedi [[Processi e Convenzioni]] per come funziona questo vault.
